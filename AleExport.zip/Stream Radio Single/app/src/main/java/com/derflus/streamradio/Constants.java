package com.derflus.streamradio;

public class Constants {
    public interface ACTION {
        String STARTFOREGROUND_ACTION = "com.nkdroid.alertdialog.action.startforeground";
        String STOPFOREGROUND_PLAYER = "com.nkdroid.alertdialog.action.stopforegroundplayer";
        String STOPFOREGROUND_ACTION = "com.nkdroid.alertdialog.action.stopforeground";
    }

    public interface NOTIFICATION_ID {
        int FOREGROUND_SERVICE = 1;
    }
}
